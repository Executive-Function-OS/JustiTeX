# JustiTeX Pro: Oregon & Federal Court LaTeX Pleading Templates

Version 2.0 Pro Edition
Developed by Precedent Systems
Licensed under the MIT License

JustiTeX Pro is an engineering-grade legal typesetting system designed specifically for Oregon state circuit courts, the Oregon Court of Appeals, and the United States District Court for the District of Oregon.

Built on standard LaTeX, JustiTeX Pro completely eliminates the layout corruption, line-number drift, and formatting rejections commonly caused by Microsoft Word and Google Docs templates.

## Why Legal Professionals and Litigants Choose JustiTeX Pro

In high-stakes litigation, document formatting matters. Oregon Uniform Trial Court Rule (UTCR) 2.010 and Federal Local Rule (LR) 10-1 mandate strict page geometry, line numbering, margin spacing, and caption layouts. 

When drafting in word processors:
- Editing a single sentence frequently breaks 28-line numbered grids across multiple pages.
- Tables, exhibits, and signatures randomly shift across page breaks.
- Converting to PDF often introduces non-standard fonts and layout shifts that cause clerk e-filing rejections.

JustiTeX Pro solves this permanently:
- Mathematical 28-Line Alignment: Every single text baseline is bound directly to the 28-line pleading grid.
- Pre-Configured Court Compliance: Includes all mandatory statutory certifications (UTCR 5.010 conferral, ORCP 1 E declaration under penalty of perjury, UTCR 5.100 order readiness, and ORCP 9 service methods).
- Instant eFiling Acceptance: Produces clean, searchable, lightweight PDF/A compliant documents ready for Odyssey File & Serve and Federal CM/ECF.
- Works Everywhere: Compile offline using TeX Live, MiKTeX, MacTeX, or online via Overleaf without installing anything.

## What Is Included in JustiTeX Pro v2.0

### Core Oregon State Court Templates (UTCR 2.010)

1. `oregon_pleading_28line.tex`: The gold-standard 28-line Oregon Circuit Court pleading paper template. Includes double vertical margin rules at 1.30in and 1.265in, 1.5in clerk margin, baseline-tracking line numbering (1--28), and a complete sample motion.
2. `motion_template.tex`: Full-featured generic motion template with UTCR 5.010 conferral certificate, UTCR 5.020 oral argument request, statement of issues, statement of facts, points and authorities, conclusion, signature block, and integrated certificate of service.
3. `declaration_template.tex`: Oregon sworn witness and party declaration template featuring the exact statutory ORCP 1 E unsworn declaration clause under penalty of perjury, numbered factual paragraphs, and exhibit references.
4. `certificate_of_service_template.tex`: Comprehensive standalone certificate of service complying with ORCP 9 and UTCR 21.100, featuring pre-formatted options for Odyssey electronic service, first-class mail, hand delivery, and email.
5. `proposed_order_template.tex`: Court-ready proposed order with formal recitals, ordering provisions, judicial signature line, and the mandatory UTCR 5.100 Certificate of Readiness block.

### Oregon Appellate Court Template (ORAP 2.05)

6. `notice_of_appeal_template.tex`: Oregon Court of Appeals Notice of Appeal formatted pursuant to ORAP 2.05 and ORS Chapter 19. Contains party designations, judgment cross-references, transcript and record designation, jurisdictional grounds, certificate of filing with the Appellate Court Administrator, and multi-party certificate of service.

### Federal Court Template (FRCP & LR 10-1)

7. `federal_pleading_template.tex`: U.S. District Court for the District of Oregon template enforcing Federal Local Rule 10-1. Features standard 1-inch margins, 12pt font, double-spaced body, two-column caption, jury trial demand, and running footers with automated total page counts (`Page X of Y`).

### Supporting Packages & Documentation

8. `pleading.sty`: Advanced Oregon pleading paper geometry and style package.
9. `sample_motion.md`: Reference markdown source text illustrating standard legal drafting structure.
10. `QUICKSTART_GUIDE.md`: Comprehensive, beginner-friendly setup and customization guide for non-technical users.
11. `CHEAT_SHEET.md`: Quick-reference cheat sheet for all macros, statutory blocks, and compilation flags.
12. `LICENSE`: MIT License permitting both personal and commercial legal practice use.

## System Requirements

JustiTeX Pro is compatible with all modern LaTeX distributions:
- TeX Live 2020 or newer (Linux / Windows)
- MacTeX 2020 or newer (macOS)
- MiKTeX 2.9 or newer (Windows)
- Overleaf (Free cloud editor, all browsers)

No specialized external packages or proprietary software are required. Standard engines `pdflatex`, `xelatex`, and `lualatex` compile the templates natively.

## Quick Compilation Instructions

To compile any template from the command line:

```bash
pdflatex motion_template.tex
```

Run twice if compiling documents that calculate total pages (such as federal pleadings):

```bash
pdflatex federal_pleading_template.tex
pdflatex federal_pleading_template.tex
```

## Commercial and Practice Rights

JustiTeX Pro is released under the permissive MIT License. Attorneys, paralegals, pro se litigants, and legal aid clinics may freely use, modify, and distribute documents created with these templates for unlimited litigation matters.

Copyright (c) 2026 Precedent Systems.
