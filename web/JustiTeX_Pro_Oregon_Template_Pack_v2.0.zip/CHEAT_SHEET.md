# JustiTeX Pro Cheat Sheet & Macro Reference

A fast, comprehensive reference guide for all LaTeX macros, environments, and court formatting rules included in the JustiTeX Pro Oregon & Federal Template Pack.

## 1. Template Roster Overview

- `oregon_pleading_28line.tex`: Oregon Circuit Court 28-line pleading paper (UTCR 2.010)
- `motion_template.tex`: Full Oregon motion with argument sections, conferral, and service
- `declaration_template.tex`: Sworn witness/party declaration with ORCP 1 E perjury clause
- `proposed_order_template.tex`: Court order with judge signature and UTCR 5.100 readiness block
- `certificate_of_service_template.tex`: Standalone certificate of service (ORCP 9 / UTCR 21)
- `notice_of_appeal_template.tex`: Oregon Court of Appeals notice (ORAP 2.05 / ORS 19)
- `federal_pleading_template.tex`: U.S. District Court double-spaced pleading (LR 10-1)
- `pleading.sty`: Specialized layout and macro definitions package

## 2. Pleading Paper Typography & Grid (UTCR 2.010)

Key geometric specifications enforced in Oregon state templates:
- Page Dimensions: Standard Letter (8.5 x 11 inches)
- Left Margin: 1.5 inches (provides clearance for clerk stamp and line numbering)
- Right Margin: 1.0 inch
- Top and Bottom Margins: 1.0 inch
- Vertical Rules: Double vertical margin line at 1.30 inches and 1.265 inches
- Grid Lines: Exactly 28 lines per page (each line height = textheight / 28)
- Baseline Alignment: Line numbers 1 through 28 track text baselines with a +3.5pt offset
- Font: 12pt Latin Modern / Computer Modern Roman (court compliant)

## 3. Core LaTeX Macros & Commands

### Section Headings

Major Headings (Centered, Bold, with Spacing):
`\pleadinghead{I. INTRODUCTION}`
or in federal templates:
`\romanhead{I. PRELIMINARY STATEMENT}`

Sub-Headings (Left-Aligned, Bold):
`\pleadingsubhead{A. Standard Under ORCP 23 A}`
or in federal templates:
`\subhead{A. Breach of Contract Allegations}`

### Running Footers

Oregon State Court:
`\fancyfoot[L]{\footnotesize TITLE OF PLEADING, Page \thepage}`

Federal Court (with automatic total page count):
`\fancyfoot[L]{\footnotesize Page \thepage{} of \pageref{LastPage} -- TITLE OF PLEADING}`

### Line Spacing

Double-spacing (Federal filings):
`\doublespacing`

Single-spacing blocks (Captions, certificates, blockquotes):
```latex
\begin{singlespace}
... content ...
\end{singlespace}
```

### Paragraph & Indentation

Paragraph Indentation: Set by default to 0.5 inches.
To start a paragraph with no indentation:
`\noindent`

To leave vertical space between paragraphs or sections:
`\vspace{0.5em}` or `\vspace{1em}`

To draw a signature rule:
`\rule{2.8in}{0.5pt}`

## 4. Oregon Mandatory Statutory Blocks

### UTCR 5.010 Conferral Certificate (Required on all civil motions)
```latex
\noindent
\textbf{UTCR 5.010 CONFERRAL CERTIFICATE:}\\
The undersigned certifies that on [Date], I conferred in good faith with [Opposing Counsel/Party] regarding the relief sought in this motion. Opposing counsel opposes this motion.
```

### UTCR 5.020 Oral Argument Request
```latex
\noindent
\textbf{UTCR 5.020 STATEMENT REGARDING ORAL ARGUMENT:}\\
Oral argument is requested. Moving party estimates [X] minutes for argument. Official court reporting services are requested.
```

### ORCP 1 E Unsworn Declaration Under Penalty of Perjury
```latex
\noindent
\textbf{I hereby declare that the above statements are true to the best of my knowledge and belief, and that I understand they are made for use as evidence in court and are subject to penalty for perjury.}
```

### UTCR 5.100 Certificate of Readiness (Proposed Orders)
```latex
\noindent
\textbf{UTCR 5.100 CERTIFICATE OF READINESS FOR JUDICIAL SIGNATURE}\\[0.5em]
This proposed order or judgment is ready for judicial signature because:
[ ] Each party affected by this order has stipulated to the order.
[ ] Each party affected by this order has approved the order.
[X] I have served a copy of this order on each party entitled to service under UTCR 5.100, and not less than 7 days have elapsed without objection.
[ ] The relief requested is ex parte or without notice as authorized by law.
```

## 5. Citations and Legal Formatting

Case Citations:
`\textit{Bailey v. Vanderkin}, 198 Or App 232, 108 P3d 600 (2005)`

Statutory References:
`ORS \S\ 19.205` or `ORCP 71 B(1)(d)`

Federal Citations:
`42 U.S.C. \S\ 1983`

Blockquotes:
```latex
\begin{quote}
\textit{Quoted judicial language or statutory text appears indented on both sides with italicized formatting.}
\end{quote}
```

Checkboxes for Certificates:
`[ X ]` or `[ \hspace{0.5em} ]`

## 6. Compilation Quick Reference

Fast terminal compilation:
`pdflatex -interaction=nonstopmode your_document.tex`

Compile with complete cross-references and page counts:
`pdflatex your_document.tex && pdflatex your_document.tex`

Clean temporary build files (`.aux`, `.log`):
`rm -f *.aux *.log *.out`
