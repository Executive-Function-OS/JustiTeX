# Marketplace Listing: JustiTeX Pro

# JustiTeX Pro: Oregon & Federal Court LaTeX Pleading Templates

Stop fighting Microsoft Word at 11:30 PM. Get court-perfect 28-line Oregon pleadings, appellate notices, and federal briefs that e-file cleanly on the first try.

## Product Summary

Platform: Gumroad / Payhip / Lemon Squeezy
Base Price: $14 (Instant Download — Lifetime Access to v2.0 Pack)
Pro Price: $19 (Pro Edition + Future Template Additions & Legislative Updates)
Format: Complete ZIP Package (.tex, .sty, .md, Guides)
License: MIT License (Commercial & Personal Use Allowed)
Target Audience: Solo practitioners, pro se litigants, paralegals, legal assistants, and legal aid clinics.

## Tags
legal templates, Oregon court, LaTeX, pleading paper, UTCR, legal formatting, pro se, Clackamas County, Multnomah County, District of Oregon, 28 line pleading, appellate brief, efiling

## Marketplace Description Copy

### The 11:30 PM Filing Nightmare Every Legal Filer Knows

You have spent weeks researching case law, drafting motions, and perfecting your legal arguments. The filing deadline is midnight.

You make one final sentence edit in Microsoft Word, and suddenly:
- The 28-line numbered grid slips two millimeters out of alignment with your text.
- Your caption jumps awkwardly onto page two.
- Your signature block splits in half across the bottom margin.
- You export to PDF, upload to Odyssey File & Serve, and hold your breath — only for the court clerk to reject your filing the next morning due to margin non-compliance.

Court rules are unforgiving. Oregon Uniform Trial Court Rule (UTCR) 2.010 and Federal Local Rule (LR) 10-1 require strict line numbering, margins, and caption geometry. Word processors were never designed for mathematical grid alignment.

### The Solution: Flawless Typography with JustiTeX Pro

JustiTeX Pro replaces unpredictable word-processor templates with rock-solid, mathematically anchored LaTeX templates. 

Every single text line aligns with laser precision to the 28-line pleading grid. Captions stay locked. Page numbers compute dynamically. Footers never wander.

Whether you compile on your desktop using TeX Live or in your web browser with free Overleaf (no software installation required), JustiTeX Pro guarantees clean, professional PDFs that command respect from judges and pass court clerk scrutiny without friction.

### Key Selling Points

- 100% Oregon UTCR 2.010 Compliant: Precise 28-line pleading grid, double margin rules at 1.30in and 1.265in, 1.5in clerk binding margin, and synchronized baseline numbers.
- Pre-Built Oregon Statutory Blocks: Never look up mandatory rule language again. Includes the exact statutory wording for UTCR 5.010 Conferral, UTCR 5.020 Oral Argument, ORCP 1 E Declarations under Penalty of Perjury, and UTCR 5.100 Certificates of Readiness.
- Federal District Court Ready: Includes a dedicated U.S. District Court (District of Oregon) template complying with Local Rule 10-1 (12pt font, double-spaced body, running `Page X of Y` footers).
- Oregon Court of Appeals Template: Built to ORAP 2.05 standards with designation of record, jurisdictional citations, and dual certificates of filing and service.
- Zero Technical Expertise Required: Comes with our beginner-friendly Quickstart Guide. If you can fill in a form, you can produce publication-grade legal documents in minutes.
- Works in Free Web Browsers: Fully compatible with Overleaf. Drag, drop, edit your text, and click Recompile.

### What Is Included in JustiTeX Pro v2.0

1. Oregon 28-Line Pleading Paper (`oregon_pleading_28line.tex`)
The flagship Oregon state court template for Circuit Court filings.

2. Generic Motion & Legal Memorandum (`motion_template.tex`)
Full motion architecture containing Issues Presented, Facts, Legal Points and Authorities, UTCR 5.010 conferral, UTCR 5.020 oral argument requests, and integrated certificate of service.

3. Oregon Sworn Witness & Party Declaration (`declaration_template.tex`)
Sworn testimony template equipped with the statutory ORCP 1 E unsworn declaration under penalty of perjury, numbered factual paragraphs, and exhibit markers.

4. Proposed Court Order (`proposed_order_template.tex`)
Judge-ready order template with formal decree clauses, judicial signature line, and mandatory UTCR 5.100 Certificate of Readiness checkboxes.

5. Certificate of Service (`certificate_of_service_template.tex`)
Multi-option service document complying with ORCP 9 and UTCR 21.100 (Odyssey electronic filing, first-class mail, hand delivery, and email).

6. Oregon Court of Appeals Notice of Appeal (`notice_of_appeal_template.tex`)
Complete notice of appeal pursuant to ORAP 2.05 and ORS Chapter 19 with trial court record designations and appellate filing certifications.

7. U.S. District Court Pleading Template (`federal_pleading_template.tex`)
Double-spaced federal pleading formatted for the District of Oregon under LR 10-1 with automated total page counting.

8. Core Style Engine (`pleading.sty`)
High-precision package for advanced pleading grid typography and caption geometry.

9. Sample Legal Motion Reference (`sample_motion.md`)
Drafting outline and Markdown source reference.

10. Non-Technical Quickstart Guide (`QUICKSTART_GUIDE.md`)
Step-by-step installation instructions for Windows, Mac, Linux, and Overleaf, plus styling tips and e-filing advice.

11. Fast Macro Cheat Sheet (`CHEAT_SHEET.md`)
One-page reference sheet with all commands, statutory clauses, citation syntax, and compilation flags.

12. Permissive Commercial License (`LICENSE`)
MIT License permitting unlimited use in your legal practice or personal cases.

### Choose Your Tier

Base Edition ($14):
- Complete JustiTeX Pro v2.0 Template Pack (all 7 templates + style package)
- Quickstart Guide, Macro Cheat Sheet, and Sample Files
- Lifetime license for personal and commercial practice use

Pro Lifetime Edition ($19):
- Everything in the Base Edition
- Free lifetime updates for future template additions (Discovery Requests, Subpoenas, Appellate Briefs)
- Free updates whenever Oregon UTCR or Federal Local Rules are revised

### Frequently Asked Questions

Do I need to know how to code to use this?
No. Every template contains clear placeholder text like `ANNIKA ERIKSSON, Plaintiff` and `Case No. 24CV12345`. You simply replace the sample text with your own facts and arguments.

Can I use this on a Chromebook or without installing software?
Yes. You can upload the template pack into Overleaf (a free, web-based LaTeX editor), edit your pleading in your browser, and download the finished PDF instantly.

Will this work for courts outside Oregon?
While specifically optimized for Oregon Circuit Courts, the Oregon Court of Appeals, and the District of Oregon, the 28-line pleading grid and federal templates can be readily adapted for Washington, California, and other state jurisdictions requiring 28-line numbered pleading paper.

What is the refund policy?
If JustiTeX Pro fails to compile in any standard TeX distribution or Overleaf, we will provide dedicated technical support or a full refund within 30 days of purchase.
