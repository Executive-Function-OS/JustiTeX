# JustiTeX Pro Quickstart Guide

Welcome to JustiTeX Pro. This guide takes you from zero to compiling court-ready, perfectly formatted Oregon and Federal court legal documents in under ten minutes.

Whether you are a solo practitioner, paralegal, legal aid advocate, or pro se litigant, you do not need to be a programmer to use these templates.

## 1. Quickest Way to Get Started: Overleaf (Zero Installation)

If you do not want to install any software on your computer right now, you can use Overleaf, a free, browser-based LaTeX editor:

1. Open your browser and go to overleaf.com
2. Create a free account or sign in.
3. Click **New Project** > **Upload Project**.
4. Upload the `JustiTeX_Pro_Oregon_Template_Pack_v2.0.zip` file or drag individual template files into the project.
5. Select any `.tex` file (such as `motion_template.tex`) on the left panel.
6. Click the green **Recompile** button at the top.
7. Your PDF appears on the right, ready to download and file.

## 2. Installing LaTeX on Your Computer

If you prefer working offline on your desktop, install a standard LaTeX distribution:

### Windows
1. Download and install **MiKTeX** from miktex.org or **TeX Live** from tug.org/texlive.
2. We recommend **TeXstudio** (texstudio.org) or **VS Code** as your desktop editor.
3. MiKTeX automatically downloads any missing packages the first time you compile.

### macOS
1. Download and run the **MacTeX** installer from tug.org/mactex.
2. MacTeX includes **TeXShop**, a clean visual editor.
3. Alternatively, install via Homebrew in Terminal:
   `brew install --cask mactex-no-gui`

### Linux (Ubuntu / Debian / Pop!_OS)
Open your terminal and install TeX Live:
`sudo apt-get update`
`sudo apt-get install -y texlive-latex-base texlive-latex-recommended texlive-fonts-recommended texlive-latex-extra`

## 3. Compiling Your First Document via Terminal

Once LaTeX is installed, compiling is a single command. Open your terminal or command prompt, navigate to the folder containing your templates, and run:

`pdflatex motion_template.tex`

To ensure page counts and cross-references update completely, run the command twice:

`pdflatex motion_template.tex`
`pdflatex motion_template.tex`

Your PDF (`motion_template.pdf`) will be created in the same folder.

## 4. How to Customize Your Document

Every template is designed with self-explanatory placeholder fields. Open any `.tex` file in your favorite text editor (Notepad, TextEdit, VS Code, or TeXstudio).

### Customizing Court Information
Near the top of the document body, locate the court header:
```latex
\begin{center}
\textbf{IN THE CIRCUIT COURT OF THE STATE OF OREGON}\\
\textbf{FOR THE COUNTY OF CLACKAMAS}
\end{center}
```
Replace `CLACKAMAS` with your county (e.g., `MULTNOMAH`, `LANE`, `MARION`, `WASHINGTON`).

### Customizing the Caption Box (Parties & Case Number)
The caption uses two side-by-side blocks:
```latex
\noindent
\begin{minipage}[t]{0.48\textwidth}
\begin{singlespace}
\textbf{YOUR NAME,}\\
\hspace*{1.5em}\textit{Plaintiff,}\\
\vspace{0.5em}
\hspace*{2em}\textit{v.}\\
\vspace{0.5em}
\textbf{DEFENDANT NAME,} an entity,\\
\hspace*{1.5em}\textit{Defendant.}
\end{singlespace}
\end{minipage}%
\hfill
\begin{minipage}[t]{0.48\textwidth}
\begin{singlespace}
\textbf{Case No. 24CV12345}\\[0.75em]
\textbf{TITLE OF YOUR MOTION}\\[0.5em]
\textbf{ORAL ARGUMENT REQUESTED}
\end{singlespace}
\end{minipage}
```
Replace the names, case number, and document title with your own.

### Customizing the Running Footer
Pleading paper rules require a running footer identifying the document title and page number. Look for:
```latex
\fancyfoot[L]{\footnotesize PLAINTIFF'S MOTION FOR LEAVE TO AMEND, Page \thepage}
```
Update the title string inside `\fancyfoot[L]{...}` to match your pleading.

### Writing Body Paragraphs & Headings
Use the included heading commands to organize your arguments:
- Major headings: `\pleadinghead{I. STATEMENT OF FACTS}`
- Sub-headings: `\pleadingsubhead{A. Standard Under ORCP 23 A}`
- Numbered factual statements: Simply type `1. First statement.` followed by a blank line.
- Italics for case citations: `\textit{Smith v. Jones, 123 Or App 456 (2020)}`

### Signatures and Oregon Verification Clauses
Oregon declarations require the statutory ORCP 1 E unsworn statement. In `declaration_template.tex`, this is already included:
```latex
\textbf{I hereby declare that the above statements are true to the best of my knowledge and belief, and that I understand they are made for use as evidence in court and are subject to penalty for perjury.}
```
Underneath, fill in your name, contact information, and date.

## 5. Common Troubleshooting & Tips

### Special Characters in LaTeX
LaTeX uses certain characters for formatting syntax. If you want these literal symbols in your text, precede them with a backslash:
- Dollar sign: write `\$` (e.g., `\$15,000`)
- Percent sign: write `\%` (e.g., `100\%`)
- Ampersand: write `\&` (e.g., `Smith \& Associates`)
- Section symbol: write `\S\` (e.g., `ORS \S\ 19.205`)
- Underscore: write `\_` (e.g., `Case\_Record`)

### Warning: "Underfull \hbox" or "Overfull \hbox"
These are informational warnings from LaTeX about line wrapping. They will not prevent your PDF from generating. In legal pleading paper, lines are set flush with the margins, so occasional loose spacing in narrow caption columns is normal.

### Updating Page References
If you see `??` instead of page numbers (e.g., in Federal running footers like "Page 1 of ??"), re-run `pdflatex` a second time. The `lastpage` package writes the total page count during the first pass and inserts it during the second pass.

### Electronic Court Filing (eFile / Odyssey)
All JustiTeX templates generate standard PDF files conforming to the Oregon Judicial Department (OJD) and Federal CM/ECF technical requirements:
- Letter paper format (8.5 x 11 inches)
- Standard embedded Type 1 PostScript / TrueType fonts
- Clean text selectable layers for court optical character recognition (OCR)
- No interactive scripts, form fields, or security restrictions that trigger clerk rejection
