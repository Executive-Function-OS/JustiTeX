# JustiTeX Open-Access Template Pack (Beta)

Thank you for downloading the JustiTeX open-source legal typesetting template pack.

## Files Included:
1. `oregon_pleading_28line.tex` — Official Oregon UTCR 2.010 compliant 28-line pleading paper template.
2. `pleading.sty` — Core LaTeX grid geometry and margin rule definitions.
3. `federal_pleading_template.tex` — Federal District Court pleading template (FRCP / Local Rules).
4. `sample_motion.md` — Sample pro se motion layout.

## How to Compile:
To compile your document into an e-filing ready PDF using pdfTeX or XeLaTeX:

pdflatex -interaction=nonstopmode oregon_pleading_28line.tex

or

xelatex oregon_pleading_28line.tex

## Open-Source Access to Justice
JustiTeX is released under the GNU AGPLv3 license. Free for pro se litigants, legal aid clinics, and community legal workers.
